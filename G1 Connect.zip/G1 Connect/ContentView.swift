import SwiftUI

struct ContentView: View {
    @StateObject private var bluetoothManager = BluetoothManager.shared
    @StateObject private var settingsManager = SettingsManager.shared
    @StateObject private var speechRecognizer = SpeechRecognizer.shared
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            LilyView()
                .tabItem {
                    Label("Lily", systemImage: "person.circle")
                }
                .tag(0)
            
            SettingsView()
                .tabItem {
                    Label("Einstellungen", systemImage: "gearshape")
                }
                .tag(1)
            
            InfoView()
                .tabItem {
                    Label("Info", systemImage: "info.circle")
                }
                .tag(2)
        }
        .accentColor(Constants.primaryColor)
        .onAppear {
            setupApp()
        }
    }
    
    private func setupApp() {
        // Check if we should auto-connect
        if settingsManager.autoConnect,
           let lastDevice = UserDefaults.standard.string(forKey: "lastConnectedDevice") {
            bluetoothManager.startScan()
            
            // Try to connect after a short delay to allow scanning to find devices
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                bluetoothManager.connectToDevice(deviceName: lastDevice)
            }
        }
        
        // Request speech recognition permission
        SpeechRecognizer.requestPermission { granted in
            if granted {
                speechRecognizer.startListening(for: Constants.wakeWord) {
                    // Wake word detected, activate Lily
                    selectedTab = 0
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}

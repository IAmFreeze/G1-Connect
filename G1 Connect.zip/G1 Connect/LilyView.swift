import SwiftUI

struct LilyView: View {
    @StateObject private var lilyViewModel = LilyViewModel()
    @StateObject private var bluetoothManager = BluetoothManager.shared
    @State private var showingChat = false
    @State private var userInput = ""
    @State private var showingInput = false
    
    var body: some View {
        VStack(spacing: 20) {
            // Main content area
            HStack(spacing: 20) {
                // Lily avatar panel
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Constants.secondaryBackgroundColor)
                        .shadow(radius: 5)
                    
                    if let image = lilyViewModel.currentEmotionImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .padding(20)
                    } else {
                        Image(systemName: "person.circle")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(Constants.primaryColor)
                            .padding(20)
                    }
                }
                .frame(width: UIScreen.main.bounds.width * 0.4)
                
                // Text panel
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Constants.secondaryBackgroundColor)
                        .shadow(radius: 5)
                    
                    ScrollView {
                        Text(lilyViewModel.currentMessage)
                            .foregroundColor(Constants.textColor)
                            .padding()
                            .multilineTextAlignment(.leading)
                    }
                }
            }
            .padding(.horizontal)
            
            Spacer()
            
            // Input area
            VStack(spacing: 12) {
                if showingInput {
                    HStack {
                        TextField("Frage Lily etwas...", text: $userInput)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .onSubmit {
                                processUserInput()
                            }
                        
                        Button("Senden") {
                            processUserInput()
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(Constants.primaryColor)
                    }
                    .padding(.horizontal)
                }
                
                Button(showingInput ? "Eingabe verbergen" : "Mit Lily sprechen") {
                    showingInput.toggle()
                    if showingInput {
                        userInput = ""
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(Constants.primaryColor)
            }
            
            // Connection status
            HStack {
                Circle()
                    .fill(bluetoothManager.isConnected ? Constants.successColor : Constants.errorColor)
                    .frame(width: 8, height: 8)
                
                Text(bluetoothManager.connectionStatus)
                    .font(.caption)
                    .foregroundColor(Constants.secondaryTextColor)
            }
            .padding(.bottom)
        }
        .background(Constants.backgroundColor.ignoresSafeArea())
        .navigationTitle("Lily")
        .navigationBarTitleDisplayMode(.large)
        .onTapGesture {
            if !showingInput {
                lilyViewModel.generateRandomResponse()
            }
        }
    }
    
    private func processUserInput() {
        guard !userInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        
        let response = LilyResponse.processInput(userInput)
        lilyViewModel.setResponse(response)
        
        // Send to glasses if connected
        if bluetoothManager.isConnected {
            bluetoothManager.sendText(text: response.text)
            bluetoothManager.sendImage(imageName: response.emotion.imageName)
        }
        
        userInput = ""
        showingInput = false
    }
}

class LilyViewModel: ObservableObject {
    @Published var currentEmotion: LilyEmotion = .happy
    @Published var currentMessage: String = "Hallo! Ich bin Lily, deine persönliche Assistentin. Wie kann ich dir heute helfen?\n\nDu kannst mich jederzeit mit \"Hey, Lily\" aktivieren oder auf diesen Text tippen, um mit mir zu sprechen."
    @Published var currentEmotionImage: UIImage?
    
    private var emotionImages: [LilyEmotion: UIImage] = [:]
    
    init() {
        loadImages()
    }
    
    private func loadImages() {
        for emotion in LilyEmotion.allCases {
            if let image = UIImage(named: emotion.imageName) {
                emotionImages[emotion] = image
            }
        }
        
        // Set initial image
        currentEmotionImage = emotionImages[currentEmotion]
    }
    
    func setEmotion(_ emotion: LilyEmotion) {
        currentEmotion = emotion
        currentEmotionImage = emotionImages[emotion]
    }
    
    func setResponse(_ response: LilyResponse) {
        currentMessage = response.text
        setEmotion(response.emotion)
    }
    
    func generateRandomResponse() {
        let responses = [
            LilyResponse(text: "Ich kann dir mit verschiedenen Aufgaben helfen. Möchtest du das Wetter wissen, einen Timer stellen oder eine Erinnerung erstellen?", emotion: .cheerful),
            LilyResponse(text: "Hmm, lass mich darüber nachdenken... Das ist eine interessante Frage.", emotion: .thoughtful),
            LilyResponse(text: "Ich habe diese Information für dich gefunden. Möchtest du mehr Details dazu?", emotion: .happy),
            LilyResponse(text: "Es tut mir leid, aber ich kann diese Anfrage im Moment nicht verarbeiten. Könntest du es anders formulieren?", emotion: .serious),
            LilyResponse(text: "Oh! Das ist überraschend. Ich habe etwas Neues gelernt.", emotion: .surprised),
            LilyResponse(text: "Ich bin nicht sicher, ob ich dich richtig verstanden habe. Könntest du das bitte näher erläutern?", emotion: .questioning)
        ]
        
        let randomResponse = responses.randomElement()!
        setResponse(randomResponse)
    }
}

struct LilyView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            LilyView()
        }
        .preferredColorScheme(.dark)
    }
}

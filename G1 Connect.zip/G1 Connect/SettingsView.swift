import SwiftUI

struct SettingsView: View {
    @StateObject private var bluetoothManager = BluetoothManager.shared
    @StateObject private var settingsManager = SettingsManager.shared
    @State private var showingResetAlert = false
    
    var body: some View {
        NavigationView {
            List {
                // Connection Section
                Section(header: Text("Verbindung").foregroundColor(Constants.primaryColor)) {
                    HStack {
                        Text("Status")
                        Spacer()
                        HStack {
                            Circle()
                                .fill(bluetoothManager.isConnected ? Constants.successColor : Constants.errorColor)
                                .frame(width: 8, height: 8)
                            Text(bluetoothManager.connectionStatus)
                                .foregroundColor(bluetoothManager.isConnected ? Constants.successColor : Constants.secondaryTextColor)
                        }
                    }
                    
                    Button(action: {
                        if bluetoothManager.isScanning {
                            bluetoothManager.stopScan()
                        } else {
                            bluetoothManager.startScan()
                        }
                    }) {
                        HStack {
                            Image(systemName: bluetoothManager.isScanning ? "stop.circle" : "magnifyingglass")
                            Text(bluetoothManager.isScanning ? "Scan stoppen" : "Nach Brillen suchen")
                        }
                    }
                    .disabled(bluetoothManager.isConnected)
                    
                    if !bluetoothManager.pairedDevices.isEmpty {
                        ForEach(Array(bluetoothManager.pairedDevices.keys.sorted()), id: \.self) { deviceName in
                            Button(action: {
                                bluetoothManager.connectToDevice(deviceName: deviceName)
                            }) {
                                HStack {
                                    Image(systemName: "eyeglasses")
                                    Text(deviceName)
                                    Spacer()
                                    if bluetoothManager.connectedDevices[deviceName] != nil {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(Constants.successColor)
                                    }
                                }
                            }
                            .disabled(bluetoothManager.connectedDevices[deviceName] != nil)
                        }
                    }
                    
                    if bluetoothManager.isConnected {
                        Button(action: {
                            bluetoothManager.disconnectFromGlasses()
                        }) {
                            HStack {
                                Image(systemName: "xmark.circle")
                                Text("Verbindung trennen")
                            }
                            .foregroundColor(Constants.errorColor)
                        }
                    }
                    
                    Toggle("Automatisch verbinden", isOn: $settingsManager.autoConnect)
                }
                
                // Display Settings
                Section(header: Text("Display").foregroundColor(Constants.primaryColor)) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Helligkeit")
                            Spacer()
                            Text("\(settingsManager.brightness)%")
                                .foregroundColor(Constants.secondaryTextColor)
                        }
                        
                        Slider(value: Binding(
                            get: { Double(settingsManager.brightness) },
                            set: { settingsManager.brightness = Int($0) }
                        ), in: 0...100, step: 1)
                        .disabled(settingsManager.autoBrightness)
                        .tint(Constants.primaryColor)
                    }
                    
                    Toggle("Auto-Helligkeit", isOn: $settingsManager.autoBrightness)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Kontrast")
                            Spacer()
                            Text("\(settingsManager.contrast)%")
                                .foregroundColor(Constants.secondaryTextColor)
                        }
                        
                        Slider(value: Binding(
                            get: { Double(settingsManager.contrast) },
                            set: { settingsManager.contrast = Int($0) }
                        ), in: 0...100, step: 1)
                        .tint(Constants.primaryColor)
                    }
                    
                    Picker("Farbmodus", selection: $settingsManager.colorMode) {
                        Text("Standard").tag(ColorMode.standard)
                        Text("Hoher Kontrast").tag(ColorMode.highContrast)
                        Text("Nachtmodus").tag(ColorMode.night)
                    }
                }
                
                // HUD Settings
                Section(header: Text("HUD").foregroundColor(Constants.primaryColor)) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("HUD-Höhe")
                            Spacer()
                            Text("\(settingsManager.hudHeight)%")
                                .foregroundColor(Constants.secondaryTextColor)
                        }
                        
                        Slider(value: Binding(
                            get: { Double(settingsManager.hudHeight) },
                            set: { settingsManager.hudHeight = Int($0) }
                        ), in: 0...100, step: 1)
                        .tint(Constants.primaryColor)
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Transparenz")
                            Spacer()
                            Text("\(settingsManager.hudTransparency)%")
                                .foregroundColor(Constants.secondaryTextColor)
                        }
                        
                        Slider(value: Binding(
                            get: { Double(settingsManager.hudTransparency) },
                            set: { settingsManager.hudTransparency = Int($0) }
                        ), in: 0...100, step: 1)
                        .tint(Constants.primaryColor)
                    }
                    
                    Picker("Textgröße", selection: $settingsManager.textSize) {
                        Text("Klein").tag(TextSize.small)
                        Text("Mittel").tag(TextSize.medium)
                        Text("Groß").tag(TextSize.large)
                    }
                }
                
                // Power Settings
                Section(header: Text("Energie").foregroundColor(Constants.primaryColor)) {
                    Toggle("Energiesparmodus", isOn: $settingsManager.powerSaving)
                    
                    Picker("Automatisch ausschalten", selection: $settingsManager.autoOff) {
                        Text("Nie").tag(AutoOffTime.never)
                        Text("Nach 1 Minute").tag(AutoOffTime.oneMinute)
                        Text("Nach 5 Minuten").tag(AutoOffTime.fiveMinutes)
                        Text("Nach 10 Minuten").tag(AutoOffTime.tenMinutes)
                        Text("Nach 30 Minuten").tag(AutoOffTime.thirtyMinutes)
                    }
                }
                
                // Reset Section
                Section {
                    Button(action: {
                        showingResetAlert = true
                    }) {
                        HStack {
                            Image(systemName: "arrow.clockwise")
                            Text("Auf Standardwerte zurücksetzen")
                        }
                        .foregroundColor(Constants.errorColor)
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .background(Constants.backgroundColor.ignoresSafeArea())
            .navigationTitle("Einstellungen")
            .navigationBarTitleDisplayMode(.large)
            .alert("Einstellungen zurücksetzen", isPresented: $showingResetAlert) {
                Button("Abbrechen", role: .cancel) { }
                Button("Zurücksetzen", role: .destructive) {
                    resetSettings()
                }
            } message: {
                Text("Möchten Sie alle Einstellungen auf die Standardwerte zurücksetzen?")
            }
        }
    }
    
    private func resetSettings() {
        // Reset all settings to default
        settingsManager.brightness = 50
        settingsManager.autoBrightness = false
        settingsManager.contrast = 50
        settingsManager.colorMode = .standard
        settingsManager.hudHeight = 50
        settingsManager.hudTransparency = 30
        settingsManager.textSize = .medium
        settingsManager.powerSaving = false
        settingsManager.autoOff = .never
        
        // Send all settings to glasses if connected
        if bluetoothManager.isConnected {
            settingsManager.sendAllSettings()
        }
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .preferredColorScheme(.dark)
    }
}

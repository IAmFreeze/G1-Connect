import Foundation
import SwiftUI
import Combine

class SettingsManager: ObservableObject {
    static let shared = SettingsManager()
    
    // MARK: - Published Properties for SwiftUI
    // Display Settings
    @Published var brightness: Int = 50 {
        didSet {
            UserDefaults.standard.set(brightness, forKey: "brightness")
            if !autoBrightness {
                sendBrightnessCommand()
            }
        }
    }
    
    @Published var autoBrightness: Bool = false {
        didSet {
            UserDefaults.standard.set(autoBrightness, forKey: "autoBrightness")
            sendAutoBrightnessCommand()
        }
    }
    
    @Published var contrast: Int = 50 {
        didSet {
            UserDefaults.standard.set(contrast, forKey: "contrast")
            sendContrastCommand()
        }
    }
    
    @Published var colorMode: ColorMode = .standard {
        didSet {
            UserDefaults.standard.set(colorMode.rawValue, forKey: "colorMode")
            sendColorModeCommand()
        }
    }
    
    // HUD Settings
    @Published var hudHeight: Int = 50 {
        didSet {
            UserDefaults.standard.set(hudHeight, forKey: "hudHeight")
            sendHUDHeightCommand()
        }
    }
    
    @Published var hudTransparency: Int = 30 {
        didSet {
            UserDefaults.standard.set(hudTransparency, forKey: "hudTransparency")
            sendHUDTransparencyCommand()
        }
    }
    
    @Published var textSize: TextSize = .medium {
        didSet {
            UserDefaults.standard.set(textSize.rawValue, forKey: "textSize")
            sendTextSizeCommand()
        }
    }
    
    // Power Settings
    @Published var powerSaving: Bool = false {
        didSet {
            UserDefaults.standard.set(powerSaving, forKey: "powerSaving")
            sendPowerSavingCommand()
        }
    }
    
    @Published var autoOff: AutoOffTime = .never {
        didSet {
            UserDefaults.standard.set(autoOff.rawValue, forKey: "autoOff")
            sendAutoOffCommand()
        }
    }
    
    // Connection Settings
    @Published var autoConnect: Bool = true {
        didSet {
            UserDefaults.standard.set(autoConnect, forKey: "autoConnect")
        }
    }
    
    // MARK: - Initialization
    private init() {
        loadSettings()
    }
    
    // MARK: - Methods
    private func loadSettings() {
        brightness = UserDefaults.standard.integer(forKey: "brightness")
        if brightness == 0 { brightness = 50 } // Default value
        
        autoBrightness = UserDefaults.standard.bool(forKey: "autoBrightness")
        
        contrast = UserDefaults.standard.integer(forKey: "contrast")
        if contrast == 0 { contrast = 50 } // Default value
        
        if let colorModeValue = UserDefaults.standard.object(forKey: "colorMode") as? Int {
            colorMode = ColorMode(rawValue: colorModeValue) ?? .standard
        }
        
        hudHeight = UserDefaults.standard.integer(forKey: "hudHeight")
        if hudHeight == 0 { hudHeight = 50 } // Default value
        
        hudTransparency = UserDefaults.standard.integer(forKey: "hudTransparency")
        if hudTransparency == 0 { hudTransparency = 30 } // Default value
        
        if let textSizeValue = UserDefaults.standard.object(forKey: "textSize") as? Int {
            textSize = TextSize(rawValue: textSizeValue) ?? .medium
        }
        
        powerSaving = UserDefaults.standard.bool(forKey: "powerSaving")
        
        if let autoOffValue = UserDefaults.standard.object(forKey: "autoOff") as? Int {
            autoOff = AutoOffTime(rawValue: autoOffValue) ?? .never
        }
        
        autoConnect = UserDefaults.standard.bool(forKey: "autoConnect")
        if !UserDefaults.standard.contains(key: "autoConnect") {
            autoConnect = true // Default to true if not set
        }
    }
    
    // MARK: - Bluetooth Command Methods
    private func sendBrightnessCommand() {
        guard BluetoothManager.shared.isConnected, !autoBrightness else { return }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.brightnessCommand, UInt8(brightness)]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendAutoBrightnessCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let status: UInt8 = autoBrightness ? 1 : 0
        let command: [UInt8] = [Constants.commandPrefix, Constants.autoBrightnessCommand, status]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendContrastCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.contrastCommand, UInt8(contrast)]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendColorModeCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.colorModeCommand, UInt8(colorMode.rawValue + 1)]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendHUDHeightCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.hudHeightCommand, UInt8(hudHeight)]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendHUDTransparencyCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.hudTransparencyCommand, UInt8(hudTransparency)]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendTextSizeCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.textSizeCommand, UInt8(textSize.rawValue + 1)]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendPowerSavingCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        let status: UInt8 = powerSaving ? 1 : 0
        let command: [UInt8] = [Constants.commandPrefix, Constants.powerSavingCommand, status]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    private func sendAutoOffCommand() {
        guard BluetoothManager.shared.isConnected else { return }
        
        var minutes: UInt8 = 0
        switch autoOff {
        case .never:
            minutes = 0
        case .oneMinute:
            minutes = 1
        case .fiveMinutes:
            minutes = 5
        case .tenMinutes:
            minutes = 10
        case .thirtyMinutes:
            minutes = 30
        }
        
        let command: [UInt8] = [Constants.commandPrefix, Constants.autoOffCommand, minutes]
        let data = Data(command)
        BluetoothManager.shared.writeData(writeData: data, lr: "L")
        BluetoothManager.shared.writeData(writeData: data, lr: "R")
    }
    
    // Send all settings to glasses (used when connecting)
    func sendAllSettings() {
        guard BluetoothManager.shared.isConnected else { return }
        
        // Add small delays between commands to prevent overwhelming the glasses
        DispatchQueue.main.async { [weak self] in
            self?.sendBrightnessCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            self?.sendAutoBrightnessCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
            self?.sendContrastCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            self?.sendColorModeCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.sendHUDHeightCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.sendHUDTransparencyCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.sendTextSizeCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { [weak self] in
            self?.sendPowerSavingCommand()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            self?.sendAutoOffCommand()
        }
    }
}

// MARK: - Enums for Settings
enum ColorMode: Int, CaseIterable, Identifiable {
    case standard = 0
    case highContrast = 1
    case night = 2
    
    var id: Int { rawValue }
    
    var displayName: String {
        switch self {
        case .standard: return "Standard"
        case .highContrast: return "Hoher Kontrast"
        case .night: return "Nachtmodus"
        }
    }
}

enum TextSize: Int, CaseIterable, Identifiable {
    case small = 0
    case medium = 1
    case large = 2
    
    var id: Int { rawValue }
    
    var displayName: String {
        switch self {
        case .small: return "Klein"
        case .medium: return "Mittel"
        case .large: return "Groß"
        }
    }
}

enum AutoOffTime: Int, CaseIterable, Identifiable {
    case never = 0
    case oneMinute = 1
    case fiveMinutes = 2
    case tenMinutes = 3
    case thirtyMinutes = 4
    
    var id: Int { rawValue }
    
    var displayName: String {
        switch self {
        case .never: return "Nie"
        case .oneMinute: return "Nach 1 Minute"
        case .fiveMinutes: return "Nach 5 Minuten"
        case .tenMinutes: return "Nach 10 Minuten"
        case .thirtyMinutes: return "Nach 30 Minuten"
        }
    }
}

// MARK: - UserDefaults Extension
extension UserDefaults {
    func contains(key: String) -> Bool {
        return object(forKey: key) != nil
    }
}

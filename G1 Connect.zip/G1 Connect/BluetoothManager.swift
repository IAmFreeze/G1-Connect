import Foundation
import UIKit
import SwiftUI
import Combine
import CoreBluetooth

enum BluetoothError: Error {
    case notPoweredOn
    case deviceNotFound
    case connectionFailed
    case writeError
    
    var localizedDescription: String {
        switch self {
        case .notPoweredOn: return "Bluetooth ist nicht eingeschaltet"
        case .deviceNotFound: return "Gerät nicht gefunden"
        case .connectionFailed: return "Verbindung fehlgeschlagen"
        case .writeError: return "Fehler beim Senden der Daten"
        }
    }
}

class BluetoothManager: NSObject, ObservableObject {
    static let shared = BluetoothManager()
    
    // Published properties for SwiftUI
    @Published var isScanning = false
    @Published var pairedDevices: [String: (CBPeripheral?, CBPeripheral?)] = [:]
    @Published var connectedDevices: [String: (CBPeripheral?, CBPeripheral?)] = [:]
    @Published var connectionStatus = "Nicht verbunden"
    
    // Computed property for connection status
    var isConnected: Bool {
        return !connectedDevices.isEmpty
    }
    
    // Original properties from UIKit version
    private var centralManager: CBCentralManager!
    private var currentConnectingDeviceName: String?
    private var leftPeripheral: CBPeripheral?
    private var leftUUIDStr: String?
    private var rightPeripheral: CBPeripheral?
    private var rightUUIDStr: String?
    private var UARTServiceUUID: CBUUID
    private var UARTRXCharacteristicUUID: CBUUID
    private var UARTTXCharacteristicUUID: CBUUID
    private var leftWChar: CBCharacteristic?
    private var rightWChar: CBCharacteristic?
    private var leftRChar: CBCharacteristic?
    private var rightRChar: CBCharacteristic?
    private var hasStartedSpeech = false
    
    private override init() {
        UARTServiceUUID = CBUUID(string: ServiceIdentifiers.uartServiceUUIDString)
        UARTTXCharacteristicUUID = CBUUID(string: ServiceIdentifiers.uartTXCharacteristicUUIDString)
        UARTRXCharacteristicUUID = CBUUID(string: ServiceIdentifiers.uartRXCharacteristicUUIDString)
        
        super.init()
        self.centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    func startScan() {
        guard centralManager.state == .poweredOn else {
            connectionStatus = "Bluetooth ist nicht eingeschaltet"
            return
        }
        
        isScanning = true
        centralManager.scanForPeripherals(withServices: nil, options: nil)
        connectionStatus = "Suche nach Geräten..."
    }
    
    // Completion-based version for compatibility
    func startScan(completion: @escaping (Bool) -> Void) {
        startScan()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            completion(true)
        }
    }
    
    func stopScan() {
        isScanning = false
        centralManager.stopScan()
        connectionStatus = "Scan gestoppt"
    }
    
    func connectToDevice(deviceName: String) {
        centralManager.stopScan()
        isScanning = false
        
        guard let peripheralPair = pairedDevices[deviceName] else {
            connectionStatus = "Gerät nicht gefunden"
            return
        }
        
        guard let leftPeripheral = peripheralPair.0, let rightPeripheral = peripheralPair.1 else {
            connectionStatus = "Ein oder beide Peripheriegeräte wurden nicht gefunden"
            return
        }
        
        currentConnectingDeviceName = deviceName
        connectionStatus = "Verbinde mit \(deviceName)..."
        
        centralManager.connect(leftPeripheral, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: true])
        centralManager.connect(rightPeripheral, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: true])
        
        // Save last connected device
        UserDefaults.standard.set(deviceName, forKey: "lastConnectedDevice")
    }
    
    // Completion-based version for compatibility
    func connectToDevice(deviceName: String, completion: @escaping (Bool) -> Void) {
        connectToDevice(deviceName: deviceName)
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            completion(self.isConnected)
        }
    }
    
    // Alternative method signature for UIKit compatibility
    func connectToGlasses(leftDevice: CBPeripheral, rightDevice: CBPeripheral) {
        self.leftPeripheral = leftDevice
        self.rightPeripheral = rightDevice
        centralManager.connect(leftDevice, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: true])
        centralManager.connect(rightDevice, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: true])
    }
    
    func disconnectFromGlasses() {
        for (_, devices) in connectedDevices {
            if let leftPeripheral = devices.0 {
                centralManager.cancelPeripheralConnection(leftPeripheral)
            }
            if let rightPeripheral = devices.1 {
                centralManager.cancelPeripheralConnection(rightPeripheral)
            }
        }
        
        connectedDevices.removeAll()
        connectionStatus = "Alle Geräte getrennt"
    }
    
    // Completion-based version for compatibility
    func disconnectFromGlasses(completion: @escaping (Bool) -> Void) {
        disconnectFromGlasses()
        completion(true)
    }
    
    // Send image to glasses
    func sendImage(image: UIImage, to side: String) {
        guard isConnected else { return }
        
        // Convert image to 1-bit BMP format for G1 glasses
        guard let bmpData = BitmapConverter.convertToBitmap(image: image,
                                                           width: Constants.displayWidth,
                                                           height: Constants.displayHeight) else {
            print("Fehler beim Konvertieren des Bildes in BMP-Format")
            return
        }
        
        // Send image to glasses
        writeData(writeData: bmpData, lr: side)
    }
    
    // Send image by name
    func sendImage(imageName: String) {
        guard let image = UIImage(named: imageName) else {
            print("Bild nicht gefunden: \(imageName)")
            return
        }
        sendImage(image: image, to: "L")
        sendImage(image: image, to: "R")
    }
    
    // Send text to glasses
    func sendText(text: String) {
        guard isConnected else { return }
        guard let textData = text.data(using: .utf8) else { return }
        
        writeData(writeData: textData, lr: "L")
        writeData(writeData: textData, lr: "R")
    }
    
    // Activate microphone
    func activateMicrophone() {
        guard isConnected else { return }
        
        let command: [UInt8] = [0xF5, 0x10] // Example command for microphone activation
        let data = Data(command)
        writeData(writeData: data, lr: "L")
        writeData(writeData: data, lr: "R")
    }
    
    func writeData(writeData: Data, lr: String) {
        if lr == "L" {
            if let leftWChar = leftWChar, let leftPeripheral = leftPeripheral {
                leftPeripheral.writeValue(writeData, for: leftWChar, type: .withoutResponse)
            } else {
                print("leftWChar is nil, cannot write data to left peripheral")
            }
        } else if lr == "R" {
            if let rightWChar = rightWChar, let rightPeripheral = rightPeripheral {
                rightPeripheral.writeValue(writeData, for: rightWChar, type: .withoutResponse)
            } else {
                print("rightWChar is nil, cannot write data to right peripheral")
            }
        }
    }
}

// MARK: - CBCentralManagerDelegate
extension BluetoothManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            connectionStatus = "Bluetooth ist eingeschaltet"
        case .poweredOff:
            connectionStatus = "Bluetooth ist ausgeschaltet"
        default:
            connectionStatus = "Bluetooth-Status ist unbekannt oder nicht unterstützt"
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        guard let name = peripheral.name else { return }
        
        let components = name.components(separatedBy: "_")
        guard components.count > 1, let channelNumber = components[safe: 1] else { return }
        
        if name.contains("_L_") {
            pairedDevices["Pair_\(channelNumber)", default: (nil, nil)].0 = peripheral // Left device
        } else if name.contains("_R_") {
            pairedDevices["Pair_\(channelNumber)", default: (nil, nil)].1 = peripheral // Right device
        }
        
        // Notify SwiftUI views
        objectWillChange.send()
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        guard let deviceName = currentConnectingDeviceName else { return }
        guard let peripheralPair = pairedDevices[deviceName] else { return }
        
        if connectedDevices[deviceName] == nil {
            connectedDevices[deviceName] = (nil, nil)
        }
        
        if peripheralPair.0 === peripheral {
            connectedDevices[deviceName]?.0 = peripheral // Left device connected
            self.leftPeripheral = peripheral
            self.leftPeripheral?.delegate = self
            self.leftPeripheral?.discoverServices([UARTServiceUUID])
            self.leftUUIDStr = peripheral.identifier.uuidString
            print("didConnect----self.leftPeripheral---------\(String(describing: self.leftPeripheral))--self.leftUUIDStr----\(String(describing: self.leftUUIDStr))----")
        } else if peripheralPair.1 === peripheral {
            connectedDevices[deviceName]?.1 = peripheral // Right device connected
            self.rightPeripheral = peripheral
            self.rightPeripheral?.delegate = self
            self.rightPeripheral?.discoverServices([UARTServiceUUID])
            self.rightUUIDStr = peripheral.identifier.uuidString
            print("didConnect----self.rightPeripheral---------\(String(describing: self.rightPeripheral))---self.rightUUIDStr----\(String(describing: self.rightUUIDStr))-----")
        }
        
        if let leftPeripheral = connectedDevices[deviceName]?.0, let rightPeripheral = connectedDevices[deviceName]?.1 {
            connectionStatus = "Verbunden mit \(deviceName)"
            currentConnectingDeviceName = nil
            
            // Notify SwiftUI views
            objectWillChange.send()
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("\(Date()) didDisconnectPeripheral-----peripheral-----\(peripheral)--")
        
        if let error = error {
            print("Disconnect error: \(error.localizedDescription)")
        } else {
            print("Disconnected without error.")
        }
        
        // Update connection status
        if peripheral === leftPeripheral || peripheral === rightPeripheral {
            connectionStatus = "Verbindung getrennt"
            
            // Notify SwiftUI views
            objectWillChange.send()
        }
        
        // Try to reconnect
        central.connect(peripheral, options: nil)
    }
}

// MARK: - CBPeripheralDelegate
extension BluetoothManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        print("peripheral------\(peripheral)-----didDiscoverServices--------")
        
        guard let services = peripheral.services else { return }
        
        for service in services {
            if service.uuid.isEqual(UARTServiceUUID) {
                peripheral.discoverCharacteristics(nil, for: service)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        print("peripheral------\(peripheral)-----didDiscoverCharacteristicsFor----service----\(service)----")
        
        guard let characteristics = service.characteristics else { return }
        
        if service.uuid.isEqual(UARTServiceUUID) {
            for characteristic in characteristics {
                if characteristic.uuid.isEqual(UARTRXCharacteristicUUID) {
                    if peripheral.identifier.uuidString == self.leftUUIDStr {
                        self.leftRChar = characteristic
                    } else if peripheral.identifier.uuidString == self.rightUUIDStr {
                        self.rightRChar = characteristic
                    }
                } else if characteristic.uuid.isEqual(UARTTXCharacteristicUUID) {
                    if peripheral.identifier.uuidString == self.leftUUIDStr {
                        self.leftWChar = characteristic
                    } else if peripheral.identifier.uuidString == self.rightUUIDStr {
                        self.rightWChar = characteristic
                    }
                }
            }
            
            if peripheral.identifier.uuidString == self.leftUUIDStr {
                if self.leftRChar != nil && self.leftWChar != nil {
                    self.leftPeripheral?.setNotifyValue(true, for: self.leftRChar!)
                    self.writeData(writeData: Data([0x4d, 0x01]), lr: "L")
                }
            } else if peripheral.identifier.uuidString == self.rightUUIDStr {
                if self.rightRChar != nil && self.rightWChar != nil {
                    self.rightPeripheral?.setNotifyValue(true, for: self.rightRChar!)
                    self.writeData(writeData: Data([0x4d, 0x01]), lr: "R")
                }
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("subscribe fail: \(error)")
            return
        }
        
        if characteristic.isNotifying {
            print("subscribe success")
        } else {
            print("subscribe cancel")
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("\(Date()) didWriteValueFor----characteristic----\(characteristic)---- \(error)")
            return
        }
        
        print("\(Date()) didWriteValueFor----characteristic----\(characteristic)----")
    }
}

// MARK: - Array Extension
extension Array {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

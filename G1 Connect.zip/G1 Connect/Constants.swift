import Foundation
import SwiftUI

struct Constants {
    // Colors - SwiftUI
    static let backgroundColor = Color(red: 0.07, green: 0.07, blue: 0.07) // #121212
    static let secondaryBackgroundColor = Color(red: 0.12, green: 0.12, blue: 0.12) // #1E1E1E
    static let primaryColor = Color(red: 0.54, green: 0.17, blue: 0.89) // #8A2BE2 (lila)
    static let textColor = Color.white
    static let secondaryTextColor = Color(red: 0.67, green: 0.67, blue: 0.67) // #AAAAAA
    static let successColor = Color(red: 0.3, green: 0.69, blue: 0.31) // #4CAF50
    static let warningColor = Color(red: 1.0, green: 0.76, blue: 0.03) // #FFC107
    static let errorColor = Color(red: 0.96, green: 0.26, blue: 0.21) // #F44336
    
    // Colors - UIKit (for compatibility)
    static let backgroundColorUIKit = UIColor(red: 0.07, green: 0.07, blue: 0.07, alpha: 1.0)
    static let secondaryBackgroundColorUIKit = UIColor(red: 0.12, green: 0.12, blue: 0.12, alpha: 1.0)
    static let primaryColorUIKit = UIColor(red: 0.54, green: 0.17, blue: 0.89, alpha: 1.0)
    
    // Bluetooth Commands
    static let commandPrefix: UInt8 = 0xF5
    
    // Command Types
    static let brightnessCommand: UInt8 = 0x01
    static let autoBrightnessCommand: UInt8 = 0x02
    static let hudHeightCommand: UInt8 = 0x03
    static let textSizeCommand: UInt8 = 0x04
    static let hudTransparencyCommand: UInt8 = 0x05
    static let contrastCommand: UInt8 = 0x06
    static let colorModeCommand: UInt8 = 0x07
    static let powerSavingCommand: UInt8 = 0x08
    static let autoOffCommand: UInt8 = 0x09
    
    // Display Settings
    static let displayWidth = 136
    static let displayHeight = 136
    
    // Wake Word
    static let wakeWord = "Hey, Lily"
    
    // App Name
    static let appName = "G1 Connect"
    
    // Lily Emotions
    static let emotions: [LilyEmotion: String] = [
        .happy: "lily_happy",
        .cheerful: "lily_cheerful",
        .thoughtful: "lily_thoughtful",
        .serious: "lily_serious",
        .surprised: "lily_surprised",
        .questioning: "lily_questioning"
    ]
    
    // Standard Responses
    static let standardResponses: [String: String] = [
        "greeting": "Hallo! Ich bin Lily, deine persönliche Assistentin. Wie kann ich dir helfen?",
        "weather": "Das aktuelle Wetter ist sonnig mit 22°C. Ein perfekter Tag!",
        "time": "Es ist jetzt 14:30 Uhr.",
        "unknown": "Entschuldige, ich verstehe deine Anfrage nicht. Kannst du es anders formulieren?",
        "timer": "Timer für 5 Minuten gesetzt. Ich werde dich benachrichtigen, wenn die Zeit abgelaufen ist.",
        "reminder": "Ich habe eine Erinnerung für morgen um 10 Uhr erstellt: 'Meeting mit dem Team'."
    ]
}

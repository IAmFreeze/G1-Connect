import SwiftUI

@main
struct G1_ConnectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
                .onAppear {
                    // Setup any app-wide configurations
                    setupAppAppearance()
                }
        }
    }
    
    private func setupAppAppearance() {
        // Configure navigation bar appearance
        let navBarAppearance = UINavigationBarAppearance()
        navBarAppearance.configureWithOpaqueBackground()
        navBarAppearance.backgroundColor = Constants.secondaryBackgroundColorUIKit
        navBarAppearance.titleTextAttributes = [.foregroundColor: Constants.primaryColorUIKit]
        navBarAppearance.largeTitleTextAttributes = [.foregroundColor: Constants.primaryColorUIKit]
        
        UINavigationBar.appearance().standardAppearance = navBarAppearance
        UINavigationBar.appearance().compactAppearance = navBarAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navBarAppearance
        
        // Configure tab bar appearance
        let tabBarAppearance = UITabBarAppearance()
        tabBarAppearance.configureWithOpaqueBackground()
        tabBarAppearance.backgroundColor = Constants.secondaryBackgroundColorUIKit
        
        UITabBar.appearance().standardAppearance = tabBarAppearance
        UITabBar.appearance().scrollEdgeAppearance = tabBarAppearance
    }
}
